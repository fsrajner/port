/// test.cpp : Defines the entry point for the console application.

#include "mystring.h"
#include <iostream>

int main()
{
	// binary tree tests
	MyString* i5 = new MyString{ "4" };
	MyString i2{ "2" };
	MyString i3{ "3" };
	MyString i1{ "1" };
	MyString* i6 = new MyString{ "6" };
	MyString i7{ "5" };
	MyString i8{ "8" };
	MyString i4{ "7" };
	MyString i9{ "9" };
	delete i6;
	delete i5;

	// string tests
	MyString a{};
	MyString b{ "hallo" };
	MyString c{ b };
	MyString d{ std::move(c) };
	std::cin >> c;
	MyString e = b + a;
	a += e;
	a += " Welt";
	a += '!';
	d = a + '!';
	d[0]=d[1];
	std::cout << a;
	std::cout << a.getSize();

	MyString* f = new MyString{ "\nspeak english\n" };
	std::cout << *f;
	delete f;

	return 0;

}

