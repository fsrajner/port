#include "mystring.h"

/**
* class Proxy
*/

StringValue* StringValue::root = nullptr;


StringValue::StringValue(const char* str)
{
	size = strlen(str);
	string = new char[size + 1];
	copyData(string, str);
	references = 1;
	left = nullptr;
	right = nullptr;
}

StringValue::StringValue(StringValue && src) ///not used for now
{
	std::swap(string, src.string);
	src.string = nullptr;
	size = src.size;
	src.size = 0;
	references = src.references;
	src.references = 0;
}

StringValue& StringValue::insert(const char* value)
{
	if (StringValue::root == nullptr)
	{
		StringValue::root = new StringValue{ value };
		return *StringValue::root;
	}
	if (stringCompare(value, string) == 0)
	{
		references++;
		return *this;
	}
	else if (stringCompare(value, string) < 0)
	{
		if (left != nullptr)
			return left->insert(value);
		else
		{
			StringValue* insert = new StringValue{ value };
			left = insert;
			return *insert;
		}
	}
	else //if (dataCompare(value, string) > 0)
	{
		if (right != nullptr)
			return right->insert(value);
		else
		{
			StringValue* insert = new StringValue{ value };
			right = insert;
			return *insert;
		}
	}
}

bool StringValue::onDelete(char* to_delete)
{
	if (root == nullptr)
		return false;
	else {
		if (stringCompare(to_delete, root->string) == 0)
		{
			StringValue temp{ "" };
			temp.left = root;
			StringValue* removedNode = root->remove(to_delete, &temp);
			root = temp.left;
			if (removedNode != nullptr)
			{
				delete removedNode;
				return true;
			}
			else
				return false;
		}
		else {
			StringValue* removedNode = root->remove(to_delete, nullptr);
			if (removedNode != nullptr)
			{
				delete removedNode;
				return true;
			}
			else
				return false;
		}
	}
}

StringValue* StringValue::remove(const  char* value, StringValue *parent)
{
	if (stringCompare(value, string) < 0)
	{
		if (left != nullptr)
			return left->remove(value, this);
		else
			return nullptr;
	}
	else if (stringCompare(value, string) > 0)
	{
		if (right != nullptr)
			return right->remove(value, this);
		else
			return nullptr;
	}
	else
	{
		if (left != nullptr && right != nullptr)
		{
			StringValue* min = &right->minNode(this, this);
			(parent->left == this) ? parent->left = min : parent->right = min;

			StringValue* temp = left;

			left = min->left;
			min->left = temp;

			temp = right;
			right = min->right;
			min->right = temp;

			return min->right->remove(value, min);
		}
		else if (parent->left == this)
		{
			parent->left = (left != nullptr) ? left : right;
			return this;
		}
		else if (parent->right == this)
		{
			parent->right = (left != nullptr) ? left : right;
			return this;
		}
	}
}

StringValue& StringValue::minNode(StringValue* to_swap, StringValue* parent)
{
	if (left == nullptr)
	{
		(parent->left == this) ? parent->left = to_swap : parent->right = to_swap;
		return *this;
	}
	else
		return left->minNode(to_swap, this);
}

char& StringValue::operator[](const size_t idx)
{
	return string[idx];
}

int StringValue::stringCompare(const char* one, const char* the_other)
{
	return strcmp(one, the_other);
}

void StringValue::begone()
{
	if (this != nullptr)
	{
		references--;
		if (references <= 0)
		{
			onDelete(string);
		}
	}
}

StringValue::~StringValue()
{
	delete[] string;
}

/**
* class MyString
*/

MyString::MyString(const char* std)
{

	data = &StringValue::root->insert(std);

}

MyString::MyString(MyString const &the_other)
{
	data = &StringValue::root->insert(the_other.data->string);
}

MyString& MyString::operator=(MyString const &the_other)
{
	if (this != &the_other)
	{
		setString(the_other.data->string);
	}
	return *this;
}

MyString::MyString(MyString && the_other)
{

	data = the_other.data;
	the_other.data = nullptr;
}

size_t MyString::getSize()
{
	return data->size;
}

void MyString::setString(const char* newstr)
{
	data->begone();
	data = &StringValue::root->insert(newstr);
}

MyString MyString::operator + (MyString const &rhs)
{
	char* temp = new char[rhs.data->size + data->size + 1];
	copyData(temp, data->string);
	strcat(temp, rhs.data->string);

	MyString ret{ temp };
	delete temp;
	return ret;
}

MyString& MyString::operator += (MyString const &rhs)
{
	char* temp = new char[rhs.data->size + data->size + 1];
	copyData(temp, data->string);
	strcat(temp, rhs.data->string);

	setString(temp);

	delete temp;
	return *this;
}

MyString MyString::operator + (const char &rhs)
{
	char* temp = new char[data->size + 2];
	copyData(temp, data->string);
	temp[data->size] = rhs;
	temp[data->size + 1] = '\0';

	MyString ret{ temp };
	delete temp;
	return ret;
}

MyString& MyString::operator += (const char &rhs)
{
	char* temp = new char[data->size + 2];
	copyData(temp, data->string);
	temp[data->size] = rhs;
	temp[data->size + 1] = '\0';

	setString(temp);

	delete temp;
	return *this;
}

Proxy MyString::operator[](const size_t idx)
{
	return Proxy{ *this, idx };
}

MyString::~MyString()
{
	data->begone();
}

/**
* class Proxy
*/

Proxy::Proxy(MyString& mstr, size_t idx) : myString(mstr), index(idx){}

Proxy::operator const char&() const
{
	return (*myString.data)[index];
}

Proxy& Proxy::operator=(char newChar)
{
	char* newString = new char[myString.getSize() + 1];
	copyData(newString, myString.data->string);
	newString[index] = newChar;

	myString.setString(newString);
	delete newString;
	return *this;
}

Proxy& Proxy::operator=(const Proxy& the_other)
{
		char* newString = new char[myString.getSize() + 1];
	copyData(newString, myString.data->string);
	newString[index] = (*the_other.myString.data)[the_other.index];

	myString.setString(newString);
	delete newString;
	return *this;
}

std::istream& operator>>(std::istream& is, MyString& obj)
{
	std::string str;

	is >> str;

	obj.setString(str.c_str());

	return is;
}

std::ostream& operator<<(std::ostream& os, const MyString& obj)
{
	os << obj.data->string;
	return os;
}

void copyData(char* destination, const char* source)
{
	strcpy(destination, source);
}
