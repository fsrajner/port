﻿#pragma once

#include<string>
#include<iostream>
#include<utility>
#include <cstring>

/**
 * Megjegyzés: Az eredeti leadás óta javítottam a kódon, az eredeti változatra kapott megjegyzés alapján 
*/

/**
* forward feclaration
*/
class Proxy;

/**
* @class Holds the string, and has a reference counter. When the counter reaches 0, it will delete itself.
* Also the class has a binary tree, in which all the StringValues are stored. The class members' data can only be reached through pointers returned by insert.
* And the tree itself can only be entered from it's root.
* source of binary tree: http://www.algolist.net/Data_structures/Binary_search_tree/Removal
*/
class StringValue
{
private:

	/**
	* @attr Number of pointer pointing to this object.
	*/
	size_t references;

	/**
	* @attr Left node in binary tree.
	*/
	StringValue* left;

	/**
	* @attr Left node in binary tree.
	*/
	StringValue* right;

	/**
	* Default constructor of StringValue. It is private, so noone can simply declare one.
	* @param string String to be held inside the StringValue.
	*/
	StringValue(const char* string = "");

	/**
	* Move constructor of StringValue. I think this should be private as well.
	* @param source StringValue, that should be moved.
	*/
	StringValue(StringValue && source);

	/**
	* Begins a delete operation of an entry from the binary tree.
	* @param to_delete Value of the data to be removed.
	* @return true if delete was successful, false if not.
	*/
	bool onDelete(char* to_delete);

	/**
	* Recurseively goes through the binary tree, finds the wanted value and returns with it's address.
	* @param value Value of data to be removed.
	* @param parent Parent of a node.
	* @return Address of the wanted node.
	*/
	StringValue* remove(const char* value, StringValue *parent);

	/**
	* Compares two strings
	* @param one One of the strings.
	* @param the_other The other string.
	* @return 0 if they are identical, >0 if one of them is "bigger", <0, if the previous one is actually "smaller".
	*/
	int stringCompare(const char* one, const char* the_other);

	/**
	* A helper method of remove, that returns with a reference to the minimum value of a subtree.
	* @param to_swap Pointer to StringValue, that you want to swap with minimum value.
	* @param parent Parent of minimum value.
	* @return Reference to minimum value of subtree.
	*/
	StringValue& minNode(StringValue* to_swap, StringValue* parent);

	/**
	* Destructor of StringValue. You can't touch this, call begone instead.
	*/
	~StringValue();

public:

	/**
	* @attr Stored string.
	*/
	char* string;
	
	/**
	* @attr size of string.
	*/
	size_t size;

	/**
	* @attr The top of the binary tree
	*/
	static StringValue* root;

	/**
	* Returns with a reference of the StringValue to be stored, if there isn't one, creates a new node.
	* @param value Value of node.
	* @return Reference to node.
	*/
	StringValue& insert(const char* value);

	/**
	* By calling this function, you tell StringValue, that you no longer keep a reference to it.
	*/
	void begone();

	/**
	* Index operator of StringValue.
	* @param index Index of requested element.
	* @return Reference to requested element.
	*/
	char& operator[](const size_t index);
};

/**
* @class This class is the "outer shell". It only stores pointers to the real data(string).
*/
class MyString
{
private:

	/**
	* @attr Pointer to stored data.
	*/
	StringValue* data;

public:

	/**
	* Constructor of MyString
	* @param string String to be stored.
	*/
	MyString(const char* string = "");

	/**
	* Copy constructor of MyString.
	* @param the_other MyString to be copied.
	*/
	MyString(MyString const &the_other);

	/**
	* operator= of MyString
	* @param the_other MyString to be copied.
	*/
	MyString& operator=(MyString const &the_other);

	/**
	* Move constructor of MyString.
	* @param source MyString, that should be moved.
	*/
	MyString(MyString && source);

	/**
	* Returns size of string.
	* @return Size of string. ('\0' not counted)
	*/
	size_t getSize();

	/**
	* Sets value of data, to requested value.
	* @param newString New value of string.
	*/
	void setString(const char* newString);

	/**
	* Index operator.
	* @param index Index of requested element.
	* @return A Proxy class representing the requested element.
	*/
	Proxy operator[](const size_t index);

	/**
	* Combines two strings and return with the result;
	* @param rhs Right-hand side of + operand
	* @return Resullt of concatenation.
	*/
	MyString operator+(MyString const &rhs);

	/**
	* Combines two strings and return with the result;
	* @param rhs Right-hand side of + operand
	* @return Resullt of concatenation.
	*/	MyString& operator+=(MyString const &rhs);

	/**
	* Combines a string and a char, return with the result;
	* @param rhs Right-hand side of + operand
	* @return Resullt of concatenation.
	*/
	MyString operator+(char const &rhs);

	/**
	* Combines a string and a char, return with the result;
	* @param rhs Right-hand side of + operand
	* @return Resullt of concatenation.
	*/
	MyString& operator+=(char const &rhs);

	/**
	* Destructor of MyString.
	*/
	~MyString();


	friend std::ostream& operator<<(std::ostream& os, const MyString& obj);
	friend std::istream& operator>>(std::istream& is, MyString& obj);

	friend class Proxy;
};

/**
* @class A proxy class representing an element of a MyString. It's needed, so when MyString's index operator is called, it won't delete, then insert the same value into the binary tree.
*/
class Proxy
{
private:

	/**
	* @attr Reference to MyString object.
	*/
	MyString& myString;

	/**
	* @attr Index or requested element.
	*/
	size_t index;

public:

	/**
	* Constructor of proxy.
	* @param myString Represented MyString.
	* @param index Index.
	*/
	Proxy(MyString& myString, size_t index);

	/**
	* Converts class to char.
	* @return The represented char of myString
	*/
	explicit operator const char&() const;

	/**
	* Sets index element of myString, also altering myString.
	* @param newChar New Character at index.
	* @return Reference to object.
	* A javított házira akapott megjegyzés szerint javítottam const char&-ról!
	*/
	Proxy& operator=(char newChar);
	
		/**
	* Sets index element of myString, also altering myString.
	* @param newChar New Character at index.
	* @return Reference to object.
	* A javított házira akapott megjegyzés szerint adtam hozzá ezt az értékadó operátort!
	*/
	Proxy& operator=(const Proxy& the_other);

};

/**
* Copies source string to destination string
* @param destination Destination of string.
* @param source Source of string.
*/
void copyData(char* destination, const char* source);
